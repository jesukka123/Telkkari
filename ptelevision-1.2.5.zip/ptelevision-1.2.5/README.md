<div align='center'><img src='https://user-images.githubusercontent.com/111543470/198868741-d78353cf-0576-4f2e-8554-1f7e4ef4c986.png'/></div>
<div align='center'><h3><a href='https://picklemods.com/'>More Information & Scripts can be found here!</a></h3></div>

## What is this?

Basically, this serves as a free resource for servers that need a television script.

With this resource, you will be able to do the following:

- Watch Youtube & Twitch Videos / Streams.
- Broadcast your Youtube / Twitch Stream as a server-wide channel.
- Display & Browse the Web.
- Display Images and Videos (via direct link in the browser).

## What do I need?

You will need the following for this script to work.

- [Ox Lib](https://github.com/overextended/ox_lib/releases) (works with any framework)

- [Renderer](https://forum.cfx.re/t/release-generic-dui-2d-3d-renderer/131208) (works with any framework)

If you want to make a fork, please obtain permission with a valid reason.

## Need Support?

<a href='https://pickle-mods.tebex.io/contact'>Click here!</a>
